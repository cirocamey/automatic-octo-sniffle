package ConectarSQL;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author ciro_ev
 */
public class Conexion {
    private Connection con; // instanciar clase connection
    
    /**
     *     Constructor
     */
    public Conexion() {
        try {
            // comprobar el driver
            Class.forName("com.mysql.jdbc.Driver");
            String connectionURL = "jdbc:mysql://localhost:3306/Incidencias_Base_de_datos?autoReconnect=true&useSSL=false";
            //  crear conexion con bd
            con = DriverManager.getConnection(connectionURL, "root", "Lawrencio");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,"No Se Conecto Con La Base De Datos \n" + e);
        }
    }

    public Connection getConexion(){
        return con;
    }
}

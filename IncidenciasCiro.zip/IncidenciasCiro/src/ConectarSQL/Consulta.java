package ConectarSQL;
import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * @author ciro_ev
 */
public class Consulta extends Conexion{
    private ResultSet resultado;

    public Consulta() {
        super();
    }

    public ResultSet getResultado(String Consulta){
        try {
            //  Crear un objeto preparedstatement
            Statement consulta = super.getConexion().createStatement();
            // Inicializa una consulta y la guarda en rs
            resultado = consulta.executeQuery(Consulta);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No Se Realizo Correctamente La Consulta  " + e);
        }
        return resultado;
    }
    
    public void Insertar(String consulta){
        try {
            Statement st = super.getConexion().createStatement();
            st.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "Se ha insertado correctamente");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error insertando datos\n" + ex);
        }
    }
    
    public void Actualizar(String consulta){
        try {
            Statement st = super.getConexion().createStatement();
            st.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "Se ha actualizado correctamente");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error actualizando datos\n" + ex);
        }
    }
    
    public void Eliminar(String consulta){
        try {
            Statement st = super.getConexion().createStatement();
            st.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "Se ha eliminado correctamente");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error eliminando datos\n" + ex);
        }
    }
    
    public void InsertarBDd(String consulta) throws SQLException{
        try{
            Statement obj = super.getConexion().createStatement();
            obj.executeLargeUpdate(consulta);
        
        }catch(Exception e){   
        }   
    }  
    
    
    public void EliminarBDD(String consulta){
        try {
            Statement obj = super.getConexion().createStatement();
            obj.executeLargeUpdate(consulta);
            JOptionPane.showInternalMessageDialog(null,"Registro Eliminado");
        } catch (SQLException ex) {
            Logger.getLogger(Consulta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static String Encriptar(String Pass) throws Exception{
        int size;
        MessageDigest md= MessageDigest.getInstance("MD5");
        byte[] b=md.digest(Pass.getBytes());
        size=b.length;
        StringBuffer h=new StringBuffer(size);
        
        for(int i=0; i<size; i++){
            int u=b[i]&255;
            
            if(u<16){
                h.append("0"+Integer.toHexString(u));
            }
            else{
                h.append(Integer.toHexString(u));
            }
        }
        return h.toString();   
    }
}

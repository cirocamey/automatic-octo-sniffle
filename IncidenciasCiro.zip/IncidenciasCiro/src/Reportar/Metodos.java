/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportar;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import ConectarSQL.Consulta;
import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;      
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sam
 */
public class Metodos {
    
       int contador=0;
       Consulta c=new Consulta();
       private ResultSet rs;
       public Metodos(){
 
        }
       
        public String Fecha_Actual(){
            Date fecha=new Date();
            SimpleDateFormat ff=new SimpleDateFormat("YYY-MM-dd");
            return ff.format(fecha);
        }
        
        public String Hora(){
            Date hora=new Date();
            SimpleDateFormat ff=new SimpleDateFormat("HH:mm:ss");
            return ff.format(hora);
        }
        
       
        public void CargarCombo(String consulta,JComboBox Combo,String campo) throws SQLException{
             contador=0;
             String sql;
             Combo.removeAllItems();
             Combo.addItem("Seleccione");
             rs=c.getResultado(consulta);
            while(rs.next()){
                Combo.addItem(rs.getString(campo));
        }
            contador++;
      
    } 
         public void cargarText(String consulta,JTextField jt,String campo) throws SQLException{
            rs=c.getResultado(consulta);
            while(rs.next())
                {
                    String a = rs.getString(campo);
                    jt.setText(a);
                }
         }
         
          public int asignar(String consulta,String campo) throws SQLException{
              int result = 1;
              rs=c.getResultado(consulta);
            while(rs.next())
                {
                    int b=rs.getInt(campo);
                    result=b;
                }
            return result;
         }
         
         
         public void cargarLabel(String consulta,JLabel lb,String campo) throws SQLException{
            rs=c.getResultado(consulta);
            while(rs.next())
                {
                    String a = rs.getString(campo);
                    lb.setText(a);
                }
         }
         
         
         public void datos(String consulta,JTable tabla){
        try {
            ResultSet rstb = c.getResultado(consulta);
            ResultSetMetaData rsmd= rstb.getMetaData();
            int col=rsmd.getColumnCount();
            DefaultTableModel modelo= new DefaultTableModel();
            for(int i=1;i<=col;i++){
                modelo.addColumn(rsmd.getColumnLabel(i));
            }
            while(rstb.next()){
                String filas[]= new String[col];
                for(int j=0;j<col;j++){
                    filas[j]=rstb.getString(j+1);
                }
                modelo.addRow(filas);
            }
            tabla.setModel(modelo);
       } catch (SQLException ex) {
            Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      
    
    
}

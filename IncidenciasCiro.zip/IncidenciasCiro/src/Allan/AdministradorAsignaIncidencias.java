/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Allan;

import ConectarSQL.Consulta;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ciro_ev
 */
public class AdministradorAsignaIncidencias extends javax.swing.JFrame {

    /**
     * Creates new form AdministradorAsignaIncidencias
     */
    public AdministradorAsignaIncidencias() {
        initComponents();
    }

    AdministradorAsignaIncidencias(String pidIncidencia, String pFechaInicio, String pHoraInicio, String pcategoria, String pprioridad, String ptipoproblema, String pusuario, String pagencia) {
        initComponents();     
        this.idIncidencia = pidIncidencia;
        this.fechaInicio = pFechaInicio;
        this.horaInicio = pHoraInicio;
        this.categoria = pcategoria;
        this.prioridad = pprioridad;
        this.tipoproblema = ptipoproblema;
        this.usuario = pusuario;
        this.agencia = pagencia;
        
        filljTEmpleadosDeInformatica();
        
        filljLIncidencia();
        filljTFFechaReportada();
        filljTFHoraReportada();
        filljTFCategoria();
        filljTFPrioridad();
        filljTFUsuario();
        filljTFAgencia();
    }

    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/CooperativaSalcajaMICOOPE.png"));
        return retValue;
    }
    
    DefaultTableModel tablaEmpleadosDeInformatica = null;
    
    Consulta consulta = null;
    
    String idIncidencia = null;
    String fechaInicio = null;
    String horaInicio = null;
    String categoria = null;
    String prioridad = null;
    String tipoproblema = null;
    String usuario = null;
    String agencia = null;
    
    private void filljTEmpleadosDeInformatica(){
        try {
            // TODO add your handling code here:
            tablaEmpleadosDeInformatica = (DefaultTableModel)jTEmpleadosDeInformatica.getModel();
            int rows = tablaEmpleadosDeInformatica.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaEmpleadosDeInformatica.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPDatosTecnico`();");
            while(resultado.next()){
                String idtecnico = resultado.getString(1);
                String nombreTecnico = resultado.getString(2);
                String usuarioTecnico = resultado.getString(3);
                String puestoTecnico = resultado.getString(4);
                String tipousuarioTecnico = resultado.getString(5);
                String estadoTecnico = resultado.getString(6);
                tablaEmpleadosDeInformatica.addRow(new Object[] {idtecnico, nombreTecnico, usuarioTecnico, puestoTecnico, tipousuarioTecnico, estadoTecnico});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "No se pudo llenar la tabla de tecnicos\n" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void filljLIncidencia(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPincidencia.idincidenciaINNERempleado/usuario`('" + usuario +"');");
            while(resultado.next()){
                jLNoIncidencia.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el jLIncidencia \n" + ex);
        }
    }
    private void filljTFFechaReportada(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPincidencia.fecha_inicioINNERempleado/usuario`('" + usuario +"');");
            while(resultado.next()){
                jTFechaReportada.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el fechareportada \n" + ex);
        }
    }
    private void filljTFHoraReportada(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPincidencia.hora_inicioINNERempleado/usuario`('" + usuario +"');");
            while(resultado.next()){
                jTFHoraReportada.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el horareportada \n" + ex);
        }
    }
    private void filljTFCategoria(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPcategoria.nombreINNERincidenciaINNERempleado/usuario`('"+ usuario +"');");
            while(resultado.next()){
                jTFCategoria.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el categoria \n" + ex);
        }
    }
    private void filljTFPrioridad(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPprioridad.nombreINNERincidenciaINNERempleado`('"+ usuario +"');");
            while(resultado.next()){
                jTFPrioridad.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el categoria \n" + ex);
        }
    }
    private void filljTFUsuario(){
        jTFUsuario.setText(usuario);
    }
    private void filljTFAgencia(){
        consulta = new Consulta();
        try{
            ResultSet resultado = consulta.getResultado("CALL `SPagencia.nombreINNERempleado/usuario`('"+ usuario +"');");
            while(resultado.next()){
                jTFAgencia.setText(resultado.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el agencia \n" + ex);
        }
    }   
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLNoIncidencia = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTFAgencia = new javax.swing.JTextField();
        jTFechaReportada = new javax.swing.JTextField();
        jTFHoraReportada = new javax.swing.JTextField();
        jTFCategoria = new javax.swing.JTextField();
        jTFPrioridad = new javax.swing.JTextField();
        jTFUsuario = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTEmpleadosDeInformatica = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jBAsignar = new javax.swing.JButton();
        jBVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Asignación de incidencias");
        setBackground(new java.awt.Color(254, 254, 254));
        setIconImage(getIconImage());
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(254, 254, 254));
        jPanel1.setFocusable(false);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CooperativaSalcajaMICOOPE.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Ubuntu", 0, 24)); // NOI18N
        jLabel8.setText("Número de incidencia:");

        jLNoIncidencia.setFont(new java.awt.Font("Ubuntu", 0, 24)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(254, 254, 254));

        jLabel9.setText("Detalles de la incidencia:");

        jLabel7.setText("Usuario que la reportó:");

        jLabel5.setText("Categoría:");

        jLabel6.setText("Prioridad");

        jLabel4.setText("Hora en que se reportó:");

        jLabel2.setText("Agencia donde se reportó:");

        jLabel3.setText("Fecha en que se reportó:");

        jTFAgencia.setEditable(false);
        jTFAgencia.setBackground(new java.awt.Color(254, 254, 254));
        jTFAgencia.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFAgencia.setFocusable(false);
        jTFAgencia.setOpaque(false);

        jTFechaReportada.setEditable(false);
        jTFechaReportada.setBackground(new java.awt.Color(254, 254, 254));
        jTFechaReportada.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFechaReportada.setFocusable(false);
        jTFechaReportada.setOpaque(false);
        jTFechaReportada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFechaReportadaActionPerformed(evt);
            }
        });

        jTFHoraReportada.setEditable(false);
        jTFHoraReportada.setBackground(new java.awt.Color(254, 254, 254));
        jTFHoraReportada.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFHoraReportada.setFocusable(false);
        jTFHoraReportada.setOpaque(false);
        jTFHoraReportada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFHoraReportadaActionPerformed(evt);
            }
        });

        jTFCategoria.setEditable(false);
        jTFCategoria.setBackground(new java.awt.Color(254, 254, 254));
        jTFCategoria.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFCategoria.setFocusable(false);
        jTFCategoria.setOpaque(false);
        jTFCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFCategoriaActionPerformed(evt);
            }
        });

        jTFPrioridad.setEditable(false);
        jTFPrioridad.setBackground(new java.awt.Color(254, 254, 254));
        jTFPrioridad.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFPrioridad.setFocusable(false);
        jTFPrioridad.setOpaque(false);

        jTFUsuario.setEditable(false);
        jTFUsuario.setBackground(new java.awt.Color(254, 254, 254));
        jTFUsuario.setDisabledTextColor(new java.awt.Color(1, 1, 1));
        jTFUsuario.setFocusable(false);
        jTFUsuario.setOpaque(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFAgencia, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTFUsuario)
                                .addComponent(jTFPrioridad)
                                .addComponent(jTFCategoria)
                                .addComponent(jTFHoraReportada)
                                .addComponent(jTFechaReportada, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel9))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFechaReportada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFHoraReportada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFPrioridad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTFAgencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel3.setBackground(new java.awt.Color(254, 254, 254));

        jTEmpleadosDeInformatica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "No. Tecnico", "Nombre", "Usuario", "Puesto", "Tipo de usuario", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTEmpleadosDeInformatica);

        jLabel10.setText("Empleados del departamento de informática:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 631, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        jBAsignar.setText("Asignar");
        jBAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAsignarActionPerformed(evt);
            }
        });

        jBVolver.setText("Volver");
        jBVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addGap(35, 35, 35)
                        .addComponent(jLNoIncidencia, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jBVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1006, 1006, 1006)
                                .addComponent(jBAsignar, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 9, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(jLNoIncidencia, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(109, 109, 109))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBAsignar)
                    .addComponent(jBVolver))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTFechaReportadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFechaReportadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFechaReportadaActionPerformed

    private void jTFHoraReportadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFHoraReportadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFHoraReportadaActionPerformed

    private void jTFCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFCategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFCategoriaActionPerformed

    private void jBVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVolverActionPerformed
        // TODO add your handling code here:
        new AdministradorRevisaIncidencias().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBVolverActionPerformed

    private void jBAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAsignarActionPerformed
        // TODO add your handling code here:
        String idtecnico = jTEmpleadosDeInformatica.getValueAt(jTEmpleadosDeInformatica.getSelectedRow(), 0).toString();
        consulta = new Consulta();
        try{
            consulta.Actualizar("CALL `SPAsignarIncidencia/idempleadoTecnico-idincidencia`('"+ idtecnico +"', '"+jLNoIncidencia.getText()+"');");
            JOptionPane.showMessageDialog(null, "Incidenicia asignada");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo llenar el agencia \n" + ex);
        }
    }//GEN-LAST:event_jBAsignarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdministradorAsignaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdministradorAsignaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdministradorAsignaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdministradorAsignaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdministradorAsignaIncidencias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAsignar;
    private javax.swing.JButton jBVolver;
    private javax.swing.JLabel jLNoIncidencia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTEmpleadosDeInformatica;
    private javax.swing.JTextField jTFAgencia;
    private javax.swing.JTextField jTFCategoria;
    private javax.swing.JTextField jTFHoraReportada;
    private javax.swing.JTextField jTFPrioridad;
    private javax.swing.JTextField jTFUsuario;
    private javax.swing.JTextField jTFechaReportada;
    // End of variables declaration//GEN-END:variables
}

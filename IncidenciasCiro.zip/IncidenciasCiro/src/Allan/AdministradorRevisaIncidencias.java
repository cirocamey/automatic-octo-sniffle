/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Allan;

import Ciro.ActivacionDeUsuario;
import ConectarSQL.Consulta;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Allan
 */
public class AdministradorRevisaIncidencias extends javax.swing.JFrame {

    /**
     * Creates new form AdministradorRevisaYAsignaIncidencias
     */
    public AdministradorRevisaIncidencias() {
        initComponents();
        nAdministradorAsignaIncidencias();
        filljTSinAsignar();
    }

    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/CooperativaSalcajaMICOOPE.png"));
        return retValue;
    }
    
    DefaultTableModel tablaIncidenciasAsignadas = null;
    DefaultTableModel tablaIncidenciasResueltas = null;
    DefaultTableModel tablaIncidenciasEscalonadas = null;
    DefaultTableModel tablaIncidenciasEnEspera = null;
    DefaultTableModel tablaIncidenciasReasignadas = null;
    
    String noIncidencia;
    String fecha;
    String hora;
    String fecha_cierre;
    String categoria;
    String prioridad;
    String tipo_de_problema;
    String usuario;
    String agencia;
    String tecnico;
    Consulta consulta = null;
    Connection con = null;
    Statement st = null;
    
        
    private void filljTSinAsignar(){
        try {
            // TODO add your handling code here:
            tablaIncidenciasEnEspera = (DefaultTableModel)jTSinAsignar.getModel();
            int rows = tablaIncidenciasEnEspera.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaIncidenciasEnEspera.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPEstadoDeIncidencias`("+4+");");
            while(resultado.next()){
                noIncidencia = resultado.getString(1);
                fecha = resultado.getString(2);
                hora = resultado.getString(3);
                categoria = resultado.getString(4);
                prioridad = resultado.getString(5);
                tipo_de_problema = resultado.getString(6);
                usuario = resultado.getString(7);
                agencia = resultado.getString(8);
                tablaIncidenciasEnEspera.addRow(new Object[] {noIncidencia, fecha, hora, categoria, prioridad, tipo_de_problema, usuario, agencia});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "filljTSinAsignar" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void filljTAsignadas(){
        try {
            // TODO add your handling code here:
            tablaIncidenciasAsignadas= (DefaultTableModel)jTAsignadas.getModel();
            int rows = tablaIncidenciasAsignadas.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaIncidenciasAsignadas.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPEstadoDeIncidencias`("+1+");");
            while(resultado.next()){
                noIncidencia = resultado.getString(1);
                fecha = resultado.getString(2);
                hora = resultado.getString(3);
                categoria = resultado.getString(4);
                prioridad = resultado.getString(5);
                tipo_de_problema = resultado.getString(6);
                usuario = resultado.getString(7);
                agencia = resultado.getString(8);
                tecnico = resultado.getString(9);
                tablaIncidenciasAsignadas.addRow(new Object[] {noIncidencia, fecha, hora, categoria, prioridad, tipo_de_problema, usuario, agencia, tecnico});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "filljTAsignadas" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void filljTEscalonadas(){
        try {
            // TODO add your handling code here:
            tablaIncidenciasEscalonadas = (DefaultTableModel)jTEscalonadas.getModel();
            int rows = tablaIncidenciasEscalonadas.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaIncidenciasEscalonadas.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPEstadoDeIncidencias`("+3+");");
            while(resultado.next()){
                noIncidencia = resultado.getString(1);
                fecha = resultado.getString(2);
                hora = resultado.getString(3);
                categoria = resultado.getString(4);
                prioridad = resultado.getString(5);
                tipo_de_problema = resultado.getString(6);
                usuario = resultado.getString(7);
                agencia = resultado.getString(8);
                tablaIncidenciasEscalonadas.addRow(new Object[] {noIncidencia, fecha, hora, categoria, prioridad, tipo_de_problema, usuario, agencia});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "filljTEscalonadas" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void filljTResueltas(){
        try {
            // TODO add your handling code here:
            tablaIncidenciasResueltas = (DefaultTableModel)jTResueltas.getModel();
            int rows = tablaIncidenciasResueltas.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaIncidenciasResueltas.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPEstadoDeIncidencias`("+2+");");
            while(resultado.next()){
                noIncidencia = resultado.getString(1);
                fecha = resultado.getString(2);
                hora = resultado.getString(3);
                fecha_cierre = resultado.getString(4);
                categoria = resultado.getString(5);
                prioridad = resultado.getString(6);
                tipo_de_problema = resultado.getString(7);
                usuario = resultado.getString(8);
                agencia = resultado.getString(9);
                tablaIncidenciasResueltas.addRow(new Object[] {noIncidencia, fecha, hora, fecha_cierre, categoria, prioridad, tipo_de_problema, usuario, agencia});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "filljTResueltas" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void filljTReasignadas(){
        try {
            // TODO add your handling code here:
            tablaIncidenciasReasignadas= (DefaultTableModel)jTReasignadas.getModel();
            int rows = tablaIncidenciasReasignadas.getRowCount();
            if(rows > 0){
                for(int i=0; i<rows; i++){
                    tablaIncidenciasReasignadas.removeRow(0);
                }
            }
            consulta = new Consulta();
            ResultSet resultado = consulta.getResultado("CALL `SPEstadoDeIncidencias`("+5+");");
            while(resultado.next()){
                noIncidencia = resultado.getString(1);
                fecha = resultado.getString(2);
                hora = resultado.getString(3);
                categoria = resultado.getString(4);
                prioridad = resultado.getString(5);
                tipo_de_problema = resultado.getString(6);
                usuario = resultado.getString(7);
                agencia = resultado.getString(8);
                tablaIncidenciasReasignadas.addRow(new Object[] {noIncidencia, fecha, hora, categoria, prioridad, tipo_de_problema, usuario, agencia});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "filljTReasignadas" + ex);
            Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void nAdministradorAsignaIncidencias(){
        jTSinAsignar.addMouseListener(new MouseAdapter() {
        public void mousePressed(MouseEvent Mouse_evt) {
                if (Mouse_evt.getClickCount() == 2){
                    String pidIncidencia = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 0);
                    String pFechaInicio = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 1);
                    String pHoraInicio = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 2);
                    String pcategoria = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 3);
                    String pprioridad = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 4);
                    String ptipoproblema = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 5);
                    String pusuario = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 6);
                    String pagencia = (String) jTSinAsignar.getValueAt(jTSinAsignar.getSelectedRow(), 7);
                    new AdministradorAsignaIncidencias(pidIncidencia, pFechaInicio, pHoraInicio, pcategoria, pprioridad, ptipoproblema, pusuario, pagencia).setVisible(true);
                    dispose();
                }
            }
        });
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jBVolver = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jLPSinAsignar = new javax.swing.JLayeredPane();
        jSPSinAsignar = new javax.swing.JScrollPane();
        jTSinAsignar = new javax.swing.JTable();
        jLPAsignadas = new javax.swing.JLayeredPane();
        jSPAsignadas = new javax.swing.JScrollPane();
        jTAsignadas = new javax.swing.JTable();
        jLPEscalonadas = new javax.swing.JLayeredPane();
        jSPEscalonadas = new javax.swing.JScrollPane();
        jTEscalonadas = new javax.swing.JTable();
        jLPResueltas = new javax.swing.JLayeredPane();
        jSPResueltas = new javax.swing.JScrollPane();
        jTResueltas = new javax.swing.JTable();
        jLPReasignada = new javax.swing.JLayeredPane();
        jSPReasignada = new javax.swing.JScrollPane();
        jTReasignadas = new javax.swing.JTable();
        jBCrearUsuario = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ver estado de incidencias");
        setIconImage(getIconImage());
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(254, 254, 254));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CooperativaSalcajaMICOOPE.png"))); // NOI18N
        jLabel1.setToolTipText("");

        jBVolver.setText("Volver");
        jBVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBVolverActionPerformed(evt);
            }
        });

        jTabbedPane1.setToolTipText("");
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jSPSinAsignar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jSPSinAsignarMouseClicked(evt);
            }
        });

        jTSinAsignar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No de incidencia", "Fecha reportada", "Hora reportada", "Categoria", "Prioridad", "Tipo de problema", "Usuario", "Agencia"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jSPSinAsignar.setViewportView(jTSinAsignar);

        jLPSinAsignar.setLayer(jSPSinAsignar, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLPSinAsignarLayout = new javax.swing.GroupLayout(jLPSinAsignar);
        jLPSinAsignar.setLayout(jLPSinAsignarLayout);
        jLPSinAsignarLayout.setHorizontalGroup(
            jLPSinAsignarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1253, Short.MAX_VALUE)
            .addGroup(jLPSinAsignarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPSinAsignarLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPSinAsignar, javax.swing.GroupLayout.PREFERRED_SIZE, 1253, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jLPSinAsignarLayout.setVerticalGroup(
            jLPSinAsignarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
            .addGroup(jLPSinAsignarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPSinAsignarLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPSinAsignar, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Sin asignar", jLPSinAsignar);

        jTAsignadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No de incidencia", "Fecha reportada", "Hora reportada", "Categoria", "Prioridad", "Tipo de problema", "Usuario", "Agencia", "Tecnico"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jSPAsignadas.setViewportView(jTAsignadas);

        jLPAsignadas.setLayer(jSPAsignadas, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLPAsignadasLayout = new javax.swing.GroupLayout(jLPAsignadas);
        jLPAsignadas.setLayout(jLPAsignadasLayout);
        jLPAsignadasLayout.setHorizontalGroup(
            jLPAsignadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1253, Short.MAX_VALUE)
            .addGroup(jLPAsignadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPAsignadasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPAsignadas, javax.swing.GroupLayout.PREFERRED_SIZE, 1253, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jLPAsignadasLayout.setVerticalGroup(
            jLPAsignadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
            .addGroup(jLPAsignadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPAsignadasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPAsignadas, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Asignadas", jLPAsignadas);

        jTEscalonadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No de incidencia", "Fecha reportada", "Hora reportada", "Categoria", "Prioridad", "Tipo de problema", "Usuario", "Agencia"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jSPEscalonadas.setViewportView(jTEscalonadas);

        jLPEscalonadas.setLayer(jSPEscalonadas, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLPEscalonadasLayout = new javax.swing.GroupLayout(jLPEscalonadas);
        jLPEscalonadas.setLayout(jLPEscalonadasLayout);
        jLPEscalonadasLayout.setHorizontalGroup(
            jLPEscalonadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1253, Short.MAX_VALUE)
            .addGroup(jLPEscalonadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPEscalonadasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPEscalonadas, javax.swing.GroupLayout.PREFERRED_SIZE, 1253, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jLPEscalonadasLayout.setVerticalGroup(
            jLPEscalonadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
            .addGroup(jLPEscalonadasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPEscalonadasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPEscalonadas, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Escalonadas", jLPEscalonadas);

        jTResueltas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No de incidencia", "Fecha reportada", "Hora reportada", "Fecha de cierre", "Categoria", "Prioridad", "Tipo de problema", "Usuario", "Agencia"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jSPResueltas.setViewportView(jTResueltas);

        jLPResueltas.setLayer(jSPResueltas, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLPResueltasLayout = new javax.swing.GroupLayout(jLPResueltas);
        jLPResueltas.setLayout(jLPResueltasLayout);
        jLPResueltasLayout.setHorizontalGroup(
            jLPResueltasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1253, Short.MAX_VALUE)
            .addGroup(jLPResueltasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPResueltasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPResueltas, javax.swing.GroupLayout.PREFERRED_SIZE, 1253, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jLPResueltasLayout.setVerticalGroup(
            jLPResueltasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
            .addGroup(jLPResueltasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPResueltasLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPResueltas, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Resueltas", jLPResueltas);

        jSPReasignada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jSPReasignadaMouseClicked(evt);
            }
        });

        jTReasignadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No de incidencia", "Fecha reportada", "Hora reportada", "Categoria", "Prioridad", "Tipo de problema", "Usuario", "Agencia"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jSPReasignada.setViewportView(jTReasignadas);

        jLPReasignada.setLayer(jSPReasignada, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLPReasignadaLayout = new javax.swing.GroupLayout(jLPReasignada);
        jLPReasignada.setLayout(jLPReasignadaLayout);
        jLPReasignadaLayout.setHorizontalGroup(
            jLPReasignadaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1253, Short.MAX_VALUE)
            .addGroup(jLPReasignadaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPReasignadaLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPReasignada, javax.swing.GroupLayout.PREFERRED_SIZE, 1253, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jLPReasignadaLayout.setVerticalGroup(
            jLPReasignadaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
            .addGroup(jLPReasignadaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jLPReasignadaLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jSPReasignada, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Reasignadas", jLPReasignada);

        jBCrearUsuario.setText("Crear usuario");
        jBCrearUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCrearUsuarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jBVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBCrearUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jBCrearUsuario))
                .addGap(7, 7, 7)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBVolver)
                .addGap(30, 30, 30))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jBVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBVolverActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jBVolverActionPerformed

    private void jSPSinAsignarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSPSinAsignarMouseClicked
        // TODO add your handling code here: 
        
    }//GEN-LAST:event_jSPSinAsignarMouseClicked

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
        filljTSinAsignar();
        filljTAsignadas();
        filljTEscalonadas();
        filljTResueltas();
        filljTReasignadas();
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void jSPReasignadaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSPReasignadaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jSPReasignadaMouseClicked

    private void jBCrearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCrearUsuarioActionPerformed
        // TODO add your handling code here:
        new ActivacionDeUsuario().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBCrearUsuarioActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdministradorRevisaIncidencias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdministradorRevisaIncidencias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCrearUsuario;
    private javax.swing.JButton jBVolver;
    private javax.swing.JLayeredPane jLPAsignadas;
    private javax.swing.JLayeredPane jLPEscalonadas;
    private javax.swing.JLayeredPane jLPReasignada;
    private javax.swing.JLayeredPane jLPResueltas;
    private javax.swing.JLayeredPane jLPSinAsignar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jSPAsignadas;
    private javax.swing.JScrollPane jSPEscalonadas;
    private javax.swing.JScrollPane jSPReasignada;
    private javax.swing.JScrollPane jSPResueltas;
    private javax.swing.JScrollPane jSPSinAsignar;
    private javax.swing.JTable jTAsignadas;
    private javax.swing.JTable jTEscalonadas;
    private javax.swing.JTable jTReasignadas;
    private javax.swing.JTable jTResueltas;
    private javax.swing.JTable jTSinAsignar;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
